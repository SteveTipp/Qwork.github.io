

import json
from dataclasses import dataclass
from pathlib import Path
import matplotlib
import numpy as np
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.ticker import FormatStrFormatter, MultipleLocator


RUN_ID = "20261124T023947Z_5b416fd2"
PHASES = (0, 90, 180, 270)
SYMBOLS = range(4)
SYMBOL_COLORS = ("#007066", "#a44d08", "#5552a2", "#a33c59")
INK, GRAY, GRID = "#183541", "#4b636e", "#dae4e6"


@dataclass
class Block:
    # Rows follow sample ID order. Columns follow PHASES. Values count readout 0.
    counts: np.ndarray
    labels: np.ndarray

    def for_symbol(self, symbol):
        return self.counts[self.labels == symbol]


def load_run(directory):
    stem = f"Ramsey_Identity_Cipher_{RUN_ID}"
    measurements = json.loads((directory / f"{stem}_measurements.json").read_bytes())
    answer_key = json.loads((directory / f"{stem}_PRIVATE_key.json").read_bytes())
    if measurements["run_id"] != RUN_ID or answer_key["run_id"] != RUN_ID:
        raise ValueError("The measurements and answer key must belong to the published run.")
    if tuple(measurements["phases_deg"]) != PHASES:
        raise ValueError(f"Expected analysis phases {PHASES}.")
    shots = measurements["shots_per_phase"]
    key_rows = answer_key["late_in_message_order"]
    truth = {row["sample_id"]: row["symbol"] for row in key_rows}
    if len(truth) != len(key_rows):
        raise ValueError("Duplicate sample ID in the late answer key.")

    blocks = {}
    for stage in ("early", "late"):
        rows = measurements["blocks"][stage]["records_in_pub_order"]
        sample_ids = sorted({row["sample_id"] for row in rows})
        if stage == "late" and set(sample_ids) != set(truth):
            raise ValueError("The late sample IDs do not match the answer key.")
        row_index = {sample_id: index for index, sample_id in enumerate(sample_ids)}
        counts = np.full((len(sample_ids), len(PHASES)), -1, dtype=int)
        labels = np.full(len(sample_ids), -1, dtype=int)
        for row in rows:
            sample_id = row["sample_id"]
            i, j = row_index[sample_id], PHASES.index(row["phase_deg"])
            histogram = row["counts"]
            if counts[i, j] != -1 or set(histogram) - {"0", "1"}:
                raise ValueError(f"Duplicate setting or invalid readout for sample {sample_id}.")
            if sum(histogram.values()) != shots or min(histogram.values()) < 0:
                raise ValueError(f"Invalid shot count for {stage} sample {sample_id}.")
            counts[i, j] = histogram.get("0", 0)
            symbol = row["symbol"] if stage == "early" else truth[sample_id]
            if symbol not in SYMBOLS or labels[i] not in (-1, symbol):
                raise ValueError(f"Inconsistent symbol for {stage} sample {sample_id}.")
            labels[i] = symbol
        if np.any(counts < 0) or set(labels) != set(SYMBOLS):
            raise ValueError(f"Incomplete four-phase alphabet in the {stage} block.")
        blocks[stage] = Block(counts, labels)
    return blocks, shots


def fringe_angle(values):
    """Ramsey phase in radians. Counts and probabilities yield the same angle."""
    return np.arctan2(values[..., 3] - values[..., 1], values[..., 0] - values[..., 2])


def page(title, subtitle):
    fig = plt.figure(figsize=(12, 7.3))
    fig.text(.065, .92, title, fontsize=23.5, fontweight="bold", va="center")
    fig.text(.066, .85, subtitle, fontsize=12.2, color=GRAY, va="center")
    return fig


def footer(fig, line, detail):
    fig.add_artist(Line2D([.065, .94], [.132, .132], lw=.8, color=GRID,
                          transform=fig.transFigure))
    fig.text(.066, .086, line, fontsize=10.1, color=INK)
    fig.text(.066, .048, detail, fontsize=9.5, color=GRAY)


def save(fig, path, **options):
    fig.savefig(path, **options)
    plt.close(fig)
    print(path)


# Image 1 — How the four symbols separated on Kingston
def plot_fringe_angles(blocks, output):
    fig, axes = plt.subplots(1, 2, figsize=(9.4, 4.7), facecolor="white")
    fig.subplots_adjust(left=.09, right=.98, top=.80, bottom=.24, wspace=.26)
    fig.text(.09, .938, "How the four symbols separated on Kingston",
             fontsize=19, weight="bold", color="#142d3a")
    fig.text(.09, .872, "Measured Ramsey fringe angle on qubit 55",
             fontsize=11, color="#38515d")

    panels = [((0, 3), (-25.5, -17.9)), ((1, 2), (-7.25, .35))]
    for ax, (pair, limits) in zip(axes, panels):
        ax.set_title(f"Symbols {pair[0]:02b} and {pair[1]:02b}",
                     loc="left", weight="bold", fontsize=11, pad=9)
        early_centers = [np.degrees(fringe_angle(blocks["early"].for_symbol(s).sum(0)))
                         for s in pair]
        ax.axhline(np.mean(early_centers), ls=(0, (3, 3)), lw=1.2, color="#59666c", zorder=2)
        for offset, symbol in zip((-.115, .115), pair):
            color = SYMBOL_COLORS[symbol]
            x = np.array([0., 1.]) + offset
            centers = []
            for i, stage in enumerate(("early", "late")):
                rows = blocks[stage].for_symbol(symbol)
                angles = np.degrees(fringe_angle(rows))
                centers.append(np.degrees(fringe_angle(rows.sum(axis=0))))
                jitter = np.linspace(-.055, .055, len(rows))
                ax.scatter(x[i] + jitter, angles, s=18, facecolor=color,
                           edgecolor="none", alpha=.53, zorder=4)
            ax.plot(x, centers, color=color, lw=1.5, alpha=.88, zorder=3)
            ax.scatter(x, centers, s=41, marker="D", c=color,
                       edgecolor="white", linewidth=.85, zorder=5)
            ax.text(x[1] + .095, centers[1], f"{symbol:02b}", fontsize=10.5,
                    ha="left", va="center", color=color, weight="bold",
                    bbox=dict(facecolor="white", edgecolor="none", pad=.6, alpha=.85))
        ax.set(xlim=(-.35, 1.43), ylim=limits)
        ax.set_xticks([0, 1], ["Early · labeled", "Late · blinded"])
        ax.yaxis.set_major_locator(MultipleLocator(2))
        ax.yaxis.set_major_formatter(FormatStrFormatter("%d°"))
        ax.grid(axis="y", color="#dae3e7", lw=.65, zorder=0)
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["left", "bottom"]].set_color("#adbcc1")
        ax.tick_params(length=0, labelsize=10, pad=6, colors="#304650")

    legend = [
        Line2D([], [], marker="o", ms=5, ls="", color="#82979d", label="One symbol measurement"),
        Line2D([], [], marker="D", ms=6, color="#38525e", label="Pooled class angle"),
        Line2D([], [], ls=(0, (3, 3)), color="#59666c", label="Frozen early boundary within pair"),
    ]
    fig.legend(handles=legend, ncol=3, loc="lower left", bbox_to_anchor=(.075, .065),
               frameon=False, handlelength=1.6, columnspacing=1.8, fontsize=9)
    fig.text(.09, .035, "Each measurement combines 4,096 shots at each of four phases. "
             "Panels use the same degrees per vertical interval.", fontsize=8.6, color="#52666e")
    save(fig, output / "01_How_the_four_symbols_separated_on_Kingston.png",
         dpi=165, bbox_inches="tight", pad_inches=.18)


# Image 2 — Observed minus ideal readout probability, in percentage points
def plot_ideal_comparison(blocks, shots, output):
    ideal = (1 + np.cos(np.deg2rad(PHASES))) / 2
    cmap = LinearSegmentedColormap.from_list(
        "departures", ["#235483", "#93b8cf", "#f7f8f5", "#efa77c", "#a43e19"])
    norm = Normalize(-21, 21)
    fig = page("Where Kingston departed from the ideal fringe",
               "Each cell shows how far the measured probability of reading 0 fell above or below ideal, in percentage points.")
    panels = [("early", .115, "Early · labeled"), ("late", .573, "Late · scored after unblinding")]
    for stage, left, title in panels:
        ax = fig.add_axes([left, .287, .34, .43])
        pooled = np.array([blocks[stage].for_symbol(s).mean(axis=0) / shots for s in SYMBOLS])
        difference = 100 * (pooled - ideal)
        image = ax.imshow(difference, cmap=cmap, norm=norm, aspect="auto", interpolation="nearest")
        ax.set_title(title, loc="left", fontsize=13.5, pad=13)
        ax.set_xticks(range(4), [f"{phase}°" for phase in PHASES])
        ax.set_yticks(range(4), [f"{s:02b}" for s in SYMBOLS])
        ax.set_xlabel("Analysis phase", fontsize=11, labelpad=6)
        if stage == "early":
            ax.set_ylabel("Transmitted symbol", fontsize=11, labelpad=10)
        ax.tick_params(length=0, pad=7)
        ax.set_xticks(np.arange(-.5, 4), minor=True)
        ax.set_yticks(np.arange(-.5, 4), minor=True)
        ax.grid(which="minor", color="white", lw=3)
        ax.tick_params(which="minor", length=0)
        for spine in ax.spines.values():
            spine.set_visible(False)
        for i, j in np.ndindex(difference.shape):
            value = difference[i, j]
            luminance = np.dot(cmap(norm(value))[:3], [.213, .715, .072])
            ax.text(j, i, f"{value:+.1f}".replace("-", "−"), ha="center", va="center",
                    fontsize=13.2, color="white" if luminance < .52 else INK, fontweight="bold")
    color_axis = fig.add_axes([.34, .176, .34, .016])
    bar = fig.colorbar(image, cax=color_axis, orientation="horizontal", ticks=[-20, -10, 0, 10, 20])
    bar.outline.set_visible(False)
    bar.ax.tick_params(length=0, pad=2, labelsize=9)
    footer(fig, "The ideal P(0) is 100%, 50%, 0%, and 50% at the four phases. "
           "Each value pools the shots for one symbol in one job.",
           "IBM Kingston · qubit 55 · 4,096 shots per phase per sample · "
           "8 early samples per symbol and 5–14 late samples per symbol")
    save(fig, output / "02_Kingston_vs_ideal_fringe.png", dpi=180)


# Image 3 — The symbol cloud and its angle–imbalance projection
def plot_symbol_cloud(blocks, shots, output):
    fig = page("The four symbols in three measured coordinates",
               "Each point is one four-phase measurement. The projection shows why similar fringe angles can still carry different symbols.")
    space = fig.add_axes([.045, .255, .455, .525], projection="3d", proj_type="ortho")
    plane = fig.add_axes([.618, .302, .306, .385])
    space.view_init(elev=22, azim=-53)
    space.set_box_aspect([1.65, 1.12, .93], zoom=1.0)
    for stage, marker in [("early", "o"), ("late", "D")]:
        for symbol, color in enumerate(SYMBOL_COLORS):
            probabilities = blocks[stage].for_symbol(symbol) / shots
            p0, p90, p180, p270 = probabilities.T
            angle = np.degrees(fringe_angle(probabilities))
            imbalance = 100 * (p0 + p180 - p90 - p270)
            contrast = 100 * np.hypot(p0 - p180, p270 - p90)
            style = dict(marker=marker, s=26 if stage == "early" else 21,
                         facecolors="none" if stage == "early" else color,
                         edgecolors=color, linewidths=1.05 if stage == "early" else .55, alpha=.9)
            space.scatter(angle, imbalance, contrast, depthshade=False, **style)
            plane.scatter(angle, imbalance, zorder=3, **style)
    space.set(xlim=(-27, 1), ylim=(-8, 8), zlim=(93, 98))
    space.set_xticks([-25, -15, -5])
    space.set_yticks([-6, 0, 6])
    space.set_zticks([94, 96, 98])
    space.set_xlabel("Fringe angle (°)", labelpad=4, fontsize=10)
    space.set_ylabel("Imbalance (pp)", labelpad=3, fontsize=10)
    space.set_zlabel("Contrast (%)", labelpad=0, fontsize=10)
    space.tick_params(pad=0, labelsize=8.8)
    for axis in (space.xaxis, space.yaxis, space.zaxis):
        axis.pane.set_facecolor("#f3f7f7")
        axis.pane.set_edgecolor(GRID)
        axis._axinfo["grid"].update(color=GRID, linewidth=.65)
    plane.set_title("Angle and imbalance", loc="left", fontsize=13, pad=12)
    plane.set(xlim=(-28, 2), ylim=(-8, 9), xlabel="Fringe angle (°)",
              ylabel="Imbalance (percentage points)")
    plane.set_xticks([-25, -20, -15, -10, -5, 0])
    plane.set_yticks([-6, -3, 0, 3, 6])
    plane.tick_params(length=0, labelsize=9, pad=5)
    plane.grid(color=GRID, lw=.63, zorder=0)
    plane.spines[["top", "right"]].set_visible(False)
    for symbol, (x, y) in enumerate([(-25.9, -7.05), (-9.3, 5.7), (-3., -6.), (-23.2, 7.35)]):
        plane.text(x, y, f"{symbol:02b}", color=SYMBOL_COLORS[symbol], weight="bold", fontsize=10,
                   bbox=dict(facecolor="white", alpha=.85, edgecolor="none", pad=1.1))
    legend = [
        Line2D([], [], marker="o", markerfacecolor="none", markeredgecolor=INK, lw=0,
               label="Early · 32 samples"),
        Line2D([], [], marker="D", color=INK, lw=0, label="Late · 32 samples"),
    ]
    legend.extend(Line2D([], [], marker="s", color=color, lw=0, label=f"{s:02b}")
                  for s, color in enumerate(SYMBOL_COLORS))
    fig.legend(handles=legend, loc="center", bbox_to_anchor=(.50, .184), ncol=6,
               frameon=False, fontsize=10.4, columnspacing=1.3, handletextpad=.35)
    footer(fig, "Imbalance is the sum of P(0) at 0° and 180° minus the sum at 90° and 270°, "
           "in percentage points (pp).",
           "Contrast is the length of the two measured fringe quadratures. "
           "All three coordinates come from the same four readout probabilities.")
    save(fig, output / "03_Kingston_symbol_cloud_3D.png", dpi=180)


# Image 4 — Accuracy of the fixed early decoders as the late shot budget changes
def plot_shot_budget(blocks, shots, output):
    early, late = blocks["early"], blocks["late"]
    pooled_counts = np.array([early.for_symbol(s).sum(axis=0) for s in SYMBOLS])
    class_shots = np.bincount(early.labels, minlength=4) * shots
    centers = fringe_angle(pooled_counts)
    profile = (pooled_counts + .5) / (class_shots[:, None] + 1)
    log_zero, log_one = np.log(profile.T), np.log1p(-profile.T)
    budgets = np.array([16, 32, 64, 128, 256, 512, 1024, 2048, 4096])
    if shots != budgets[-1]:
        raise ValueError("The published shot-budget figure uses 4,096 shots per phase.")
    rng = np.random.default_rng(55)
    repeats = 5000
    means = np.empty((len(budgets), 2))
    lower = np.empty_like(means)
    upper = np.empty_like(means)
    for i, budget in enumerate(budgets):
        # Draw an unordered subset of each recorded one-bit shot stream.
        zeros = rng.hypergeometric(late.counts, shots - late.counts, budget,
                                   size=(repeats, *late.counts.shape))
        angle = fringe_angle(zeros)
        distances = np.abs((angle[..., None] - centers + np.pi) % (2 * np.pi) - np.pi)
        phase_prediction = distances.argmin(axis=-1)
        profile_prediction = (zeros @ log_zero + (budget - zeros) @ log_one).argmax(axis=-1)
        correct = np.stack([(phase_prediction == late.labels).sum(axis=1),
                            (profile_prediction == late.labels).sum(axis=1)], axis=1)
        means[i] = correct.mean(axis=0)
        lower[i], upper[i] = np.quantile(correct, [.05, .95], axis=0, method="nearest")

    fig = page("How decoding accuracy changes with fewer shots",
               "The same 32 late symbols were reread using random subsets of their archived shots. Both early decoders stayed fixed.")
    ax = fig.add_axes([.095, .295, .607, .445])
    ax.set_xscale("log", base=2)
    handles = []
    for j, (color, title, marker) in enumerate([("#a45520", "Fringe angle", "o"),
                                                 ("#246982", "Four-phase profile", "D")]):
        ax.fill_between(budgets, lower[:, j], upper[:, j], color=color, alpha=.105, lw=0)
        line, = ax.plot(budgets, means[:, j], color=color, marker=marker, markerfacecolor="white",
                        ms=5.5, lw=2.1, label=title, zorder=3)
        handles.append(line)
    ax.scatter([shots] * 2, means[-1], s=56, marker="o", color=INK, zorder=5, clip_on=False)
    ax.axhline(8, color=GRAY, lw=1, ls=(0, (3, 3)))
    ax.text(19, 8.45, "Uniform guessing · 8 of 32 on average", fontsize=9, color=GRAY)
    ax.set(xlim=(13, 5200), ylim=(6.2, 34), xlabel="Shots retained per phase setting",
           ylabel="Late symbols decoded correctly")
    ax.set_xticks(budgets, [f"{x:,}" for x in budgets])
    ax.set_yticks([8, 12, 16, 20, 24, 28, 32])
    ax.tick_params(length=0, labelsize=9.1, pad=5)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", lw=.65, color=GRID)
    fig.legend(handles=handles, loc="center left", bbox_to_anchor=(.085, .193),
               ncol=2, frameon=False, fontsize=10.4)
    fig.add_artist(Line2D([.742, .742], [.304, .73], lw=1, color=GRID, transform=fig.transFigure))
    phase_mean, profile_mean = means[budgets == 1024][0]
    fig.text(.765, .678, "1,024 shots per phase", fontsize=12.4, weight="bold")
    fig.text(.765, .629, "Average correct out of 32", fontsize=10, color=GRAY)
    fig.text(.765, .568, f"{phase_mean:.1f}   Fringe angle", fontsize=12.4, color="#964813")
    fig.text(.765, .517, f"{profile_mean:.1f}   Four-phase profile", fontsize=12.4, color="#246982")
    fig.text(.765, .405, "4,096 shots per phase", fontsize=12.4, weight="bold")
    full_phase, full_profile = means[-1]
    text = (f"{full_phase:.0f}/{len(late.labels)} for both decoders" if full_phase == full_profile
            else f"{full_phase:.0f} angle · {full_profile:.0f} profile")
    fig.text(.765, .35, text, fontsize=11.6, color=INK)
    fig.text(.765, .306, "Observed in the full run", fontsize=10, color=GRAY)
    footer(fig, "Lines show mean scores. Shading covers the 5th–95th percentiles of 5,000 random "
           "subsets drawn without replacement at each shot count.",
           "Each symbol uses four phase settings. These ranges describe shot sampling within this run. "
           "Drift across hardware runs adds further uncertainty.")
    save(fig, output / "04_Kingston_shot_budget.png", dpi=180)


def main():
    directory = Path(__file__).resolve().parent
    blocks, shots = load_run(directory)
    output = directory / "Figures"
    output.mkdir(exist_ok=True)
    with plt.style.context("default"):
        plot_fringe_angles(blocks, output)
        # The first figure used Matplotlib defaults; the remaining three used Open Sans.
        available_fonts = {font.name for font in font_manager.fontManager.ttflist}
        plt.rcParams.update({
            "font.family": "Open Sans" if "Open Sans" in available_fonts else "DejaVu Sans",
            "font.size": 11, "text.color": INK, "axes.labelcolor": INK,
            "xtick.color": GRAY, "ytick.color": GRAY, "axes.edgecolor": "#a5b7bc",
            "axes.titleweight": "bold", "axes.titlecolor": INK,
            "figure.facecolor": "white", "savefig.facecolor": "white",
        })
        plot_ideal_comparison(blocks, shots, output)
        plot_symbol_cloud(blocks, shots, output)
        plot_shot_budget(blocks, shots, output)


if __name__ == "__main__":
    main()
