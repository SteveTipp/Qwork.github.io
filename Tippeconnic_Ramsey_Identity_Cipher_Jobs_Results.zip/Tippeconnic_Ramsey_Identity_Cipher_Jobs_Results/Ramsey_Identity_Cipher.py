
import csv
import json
import logging
import math
import os
from datetime import datetime, timezone
from pathlib import Path
from secrets import SystemRandom, randbits, token_hex
from qiskit import ClassicalRegister, QuantumCircuit, QuantumRegister, transpile
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2
from qiskit_ibm_runtime.models import BackendProperties
from qiskit_ibm_runtime.models.exceptions import BackendPropertyError


# IBM Quantum and acquisition settings
TOKEN = ""     
INSTANCE = ""  
BACKEND = "ibm_kingston"
CAL_JSON = ""  
RESULT_DIR = Path("")
SHOTS = 4096   # Per phase setting. Four settings give 16,384 shots per symbol.
EARLY_SAMPLES_PER_SYMBOL = 8
LATE_SYMBOLS = 32  # Used when PLAINTEXT_BITS is empty.
PLAINTEXT_BITS = ""  # Optional even-length binary message, in transmission order.
WORD_REPEATS = 4


# Each sign sets the virtual frame for four successive physical SX pulses.
WORDS = ((+1, +1, +1), (+1, -1, +1), (-1, +1, -1), (-1, -1, -1))
PHASES_DEG = (0, 90, 180, 270)
log = logging.getLogger(__name__)


# Calibration-based qubit pick
def best_qubit(backend):
    path = Path(CAL_JSON).expanduser() if CAL_JSON else None
    rows = None
    properties = None
    if path is None:
        properties = backend.properties()
    elif path.suffix.lower() == ".csv":
        with path.open(encoding="utf-8-sig", newline="") as file:
            rows = list(csv.DictReader(file))
    else:
        with path.open(encoding="utf-8-sig") as file:
            data = json.load(file)
        if isinstance(data, list):
            rows = data
        else:
            properties = BackendProperties.from_dict(data)

    candidates = []
    if rows is not None:
        for row in rows:
            row = {key.strip(): value for key, value in row.items()}
            try:
                candidates.append((int(row["Qubit"]), float(row["√x (sx) error"]),
                                   float(row["T1 (us)"]), float(row["T2 (us)"])))
            except (TypeError, ValueError):
                continue  # An uncharacterized qubit can have empty cells.
    else:
        if properties is None or properties.backend_name != backend.name:
            raise ValueError(f"Expected calibration properties for {backend.name}.")
        for q in range(min(len(properties.qubits), backend.num_qubits)):
            if not properties.is_qubit_operational(q):
                continue
            try:
                candidates.append((q, properties.gate_error("sx", [q]),
                                   properties.t1(q) * 1e6, properties.t2(q) * 1e6))
            except BackendPropertyError:
                continue

    eligible = [
        (error, -t1, -t2, q) for q, error, t1, t2 in candidates
        if 0 <= q < backend.num_qubits and 0 <= error <= 1
        and 0 < t1 < math.inf and 0 < t2 < math.inf
        and all(backend.target.instruction_supported(operation_name=gate, qargs=(q,))
                for gate in ("sx", "rz", "measure"))
    ]
    if not eligible:
        raise ValueError("No qubit has usable SX, T1, T2 and readout calibration.")
    error, neg_t1, neg_t2, q = min(eligible)
    return q, {"source": str(path) if path else "live backend properties",
               "sx_error": error, "t1_us": -neg_t1, "t2_us": -neg_t2}


# Identity word and Ramsey interferometer
def sx_pulses(qc, q, number):
    for _ in range(number):
        qc.sx(q)
        qc.barrier(q)  # Preserve every physical drive, including adjacent SXs.


def append_identity_word(qc, q, symbol):
    # SX**4 = I, so each RZ-framed quartet is exactly I for either frame.
    # The outer SX and SX**3 are inverses. They rotate residual drive-angle
    # error about the framed +/-Y axis into a Ramsey-sensitive Z phase.
    sx_pulses(qc, q, 1)
    for _ in range(WORD_REPEATS):
        for sign in WORDS[symbol]:
            frame = sign * math.pi / 2
            qc.rz(frame, q)
            sx_pulses(qc, q, 4)
            qc.rz(-frame, q)
            qc.barrier(q)
    sx_pulses(qc, q, 3)


def ramsey_circuit(symbol, phase_deg):
    probe = QuantumRegister(1, "probe")
    readout = ClassicalRegister(1, "readout")
    qc = QuantumCircuit(probe, readout, name="ramsey")
    q = probe[0]
    sx_pulses(qc, q, 1)  # First Ramsey pi/2 pulse.
    append_identity_word(qc, q, symbol)
    # The pi offset inverts the second splitter at phase zero. For every ideal
    # word P(readout=0) = (1 + cos(phase)) / 2.
    qc.rz(math.radians(phase_deg - 180), q)
    qc.sx(q)
    qc.measure(q, readout[0])
    return qc


def native_sequence(qc, physical):
    sequence = []
    for item in qc.data:
        gate = item.operation
        if gate.name == "barrier":
            continue
        if [qc.find_bit(bit).index for bit in item.qubits] != [physical]:
            raise ValueError("Transpilation moved an operation off the selected qubit.")
        if gate.name == "rz":
            angle = round(float(gate.params[0]) % math.tau, 12)
            if angle:
                sequence.append(("rz", angle))
        else:
            sequence.append((gate.name, None))
    return sequence


def compile_alphabet(backend, physical):
    templates = {}
    durations = set()
    for symbol in range(len(WORDS)):
        for phase in PHASES_DEG:
            raw = ramsey_circuit(symbol, phase)
            isa = transpile(raw, backend=backend, initial_layout=[physical],
                            optimization_level=0)
            if native_sequence(isa, physical) != native_sequence(raw, 0):
                raise ValueError("The compiler changed the native Ramsey pulse sequence.")
            durations.add(isa.estimate_duration(backend.target, unit="dt"))
            templates[symbol, phase] = isa
    if len(durations) != 1:
        raise ValueError(f"Compiled Ramsey durations differ in backend ticks: {durations}")
    return templates, int(durations.pop())


# Acquisition plan and private answer key
def acquisition_plan():
    if min(EARLY_SAMPLES_PER_SYMBOL, LATE_SYMBOLS, WORD_REPEATS, SHOTS) < 1:
        raise ValueError("Sample counts, word repeats and shots must be positive.")
    bits = PLAINTEXT_BITS
    if len(bits) % 2 or set(bits) - {"0", "1"}:
        raise ValueError("PLAINTEXT_BITS must contain complete two-bit symbols.")
    plaintext = ([int(bits[i:i+2], 2) for i in range(0, len(bits), 2)]
                 if bits else [randbits(2) for _ in range(LATE_SYMBOLS)])
    early = list(range(len(WORDS))) * EARLY_SAMPLES_PER_SYMBOL
    rng = SystemRandom()
    rng.shuffle(early)
    key = []
    for sample_id, plain in enumerate(plaintext):
        mask = randbits(2)
        key.append({"sample_id": sample_id, "plaintext": plain, "mask": mask,
                    "symbol": plain ^ mask})

    plans = {}
    for stage, symbols in (("early", early), ("late", [row["symbol"] for row in key])):
        settings = [(sample_id, symbol, phase) for sample_id, symbol in enumerate(symbols)
                    for phase in PHASES_DEG]
        rng.shuffle(settings)  # Submitted order carries no systematic symbol or phase cue.
        plans[stage] = settings
    return plans, key


def save_measurements(path, data):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


# Runtime execution and result extraction
def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
    plans, key = acquisition_plan()
    service = QiskitRuntimeService(channel="ibm_quantum_platform" if TOKEN else None,
                                   token=TOKEN or None,
                                   instance=INSTANCE or None)
    backend = service.backend(BACKEND)
    physical, calibration = best_qubit(backend)
    templates, duration_dt = compile_alphabet(backend, physical)
    log.info("Backend %s | qubit %d | all Ramsey circuits %d dt", backend.name,
             physical, duration_dt)
    sampler = SamplerV2(mode=backend, options={
        "dynamical_decoupling": {"enable": False},
        "twirling": {"enable_gates": False, "enable_measure": False},
    })

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + token_hex(4)
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    prefix = f"Ramsey_Identity_Cipher_{run_id}"
    public_path = RESULT_DIR / f"{prefix}_measurements.json"
    private_path = RESULT_DIR / f"{prefix}_PRIVATE_key.json"
    with open(private_path, "x", encoding="utf-8",
              opener=lambda path, flags: os.open(path, flags, 0o600)) as file:
        json.dump({"run_id": run_id, "late_in_message_order": key}, file, indent=2)

    out = {"experiment": "Ramsey identity cipher", "run_id": run_id, "backend": backend.name,
           "physical_qubit": physical, "calibration": calibration, "shots_per_phase": SHOTS,
           "phases_deg": PHASES_DEG, "word_frame_signs": WORDS, "word_repeats": WORD_REPEATS,
           "compiled_duration_dt": duration_dt, "dt_seconds": backend.dt, "blocks": {}}
    log.info("Measurements -> %s", public_path)
    log.info("Private answer key -> %s", private_path)

    # job.result() and the early checkpoint both finish before the late submission.
    for stage, settings in plans.items():
        records = []
        circuits = []
        for sample_id, symbol, phase in settings:
            record = {"sample_id": sample_id, "phase_deg": phase}
            if stage == "early":
                record["symbol"] = symbol
            records.append(record)
            circuits.append(templates[symbol, phase])
        block = {"records_in_pub_order": records,
                 "submission_requested_utc": datetime.now(timezone.utc).isoformat()}
        out["blocks"][stage] = block
        save_measurements(public_path, out)
        job = sampler.run(circuits, shots=SHOTS)
        block["job_id"] = job.job_id()
        log.info("%s job %s | %d settings x %d shots", stage, job.job_id(), len(records), SHOTS)
        save_measurements(public_path, out)
        result = job.result()
        for record, pub in zip(records, result, strict=True):
            counts = pub.data.readout.get_counts()
            if sum(counts.values()) != SHOTS or counts.keys() - {"0", "1"}:
                raise ValueError(f"Unexpected one-bit counts in {stage} job {job.job_id()}.")
            record["counts"] = counts
        block["result_received_utc"] = datetime.now(timezone.utc).isoformat()
        # Record the device's acquisition windows directly from the Sampler result.
        spans = result.metadata.get("execution", {}).get("execution_spans", ())
        executor = result.metadata.get("executor")
        if executor is not None:
            spans = executor.chunk_timing
        block["qpu_windows"] = [{"start": span.start.isoformat(), "stop": span.stop.isoformat()}
                                for span in spans]
        save_measurements(public_path, out)
    log.info("Acquisition complete. Use %s for blind decoding.", public_path)


if __name__ == "__main__":
    main()
