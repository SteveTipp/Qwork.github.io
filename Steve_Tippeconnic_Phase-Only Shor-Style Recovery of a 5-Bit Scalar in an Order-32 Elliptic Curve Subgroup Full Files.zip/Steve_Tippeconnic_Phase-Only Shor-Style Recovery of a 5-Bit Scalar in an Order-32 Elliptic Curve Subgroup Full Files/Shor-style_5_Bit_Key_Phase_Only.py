
# Imports
import logging, json
import numpy as np
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit.circuit.library import QFT
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2
import pandas as pd

# IBMQ
TOKEN = ""
INSTANCE = ""
BACKEND  = "ibm_marrakesh"
CAL_CSV  = "/Users/steventippeconnic/Downloads/ibm_marrakesh_calibrations_2026-02-12T19_20_02Z.csv"
SHOTS    = 16384

# Toy parameters (order-32 subgroup)
ORDER = 32
K_SECRET = 7  # k = 7

# Logging helper
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# Calibration-based qubit pick
def best_qubits(csv_path: str, n: int) -> list[int]:
    df = pd.read_csv(csv_path)
    df.columns = df.columns.str.strip()
    winners = (
        df.sort_values(["√x (sx) error", "T1 (us)", "T2 (us)"],
                       ascending=[True, False, False])
        ["Qubit"].head(n).tolist()
    )
    log.info("Best physical qubits: %s", winners)
    return winners

N_Q = 5
N_Q_TOTAL = N_Q * 2
PHYSICAL = best_qubits(CAL_CSV, N_Q_TOTAL)

# Phase Only Oracle. Implements: |a⟩|b⟩ → exp(2πi(a + k b)/32) |a⟩|b⟩
def phase_oracle(qc, a_reg, b_reg):

    # Phase contribution from 'a'
    for i in range(N_Q):
        weight = (1 << i)
        angle = 2 * np.pi * weight / ORDER
        qc.rz(angle, a_reg[i])

    # Phase contribution from 'k * b'
    for i in range(N_Q):
        weight = (K_SECRET * (1 << i)) % ORDER
        angle = 2 * np.pi * weight / ORDER
        qc.rz(angle, b_reg[i])

# Build the Shor-style circuit
def shor_ecdlp_phase_circuit() -> QuantumCircuit:

    a = QuantumRegister(N_Q, "a")
    b = QuantumRegister(N_Q, "b")
    c = ClassicalRegister(N_Q * 2, "c")

    qc = QuantumCircuit(a, b, c, name="ECDLP_32pts_PhaseOnly")

    # Uniform superposition
    qc.h(a)
    qc.h(b)

    # Phase encoding of a + k b
    phase_oracle(qc, a, b)
    qc.barrier()

    # QFT on both registers
    qc.append(QFT(N_Q, do_swaps=False), a)
    qc.append(QFT(N_Q, do_swaps=False), b)

    qc.measure(a, c[:N_Q])
    qc.measure(b, c[N_Q:])

    return qc

# IBM Runtime execution
service = QiskitRuntimeService(channel="ibm_cloud",
                               token=TOKEN,
                               instance=INSTANCE)

backend = service.backend(BACKEND)
log.info("Backend → %s", backend.name)

qc_raw = shor_ecdlp_phase_circuit()

trans = transpile(qc_raw,
                  backend=backend,
                  initial_layout=PHYSICAL,
                  optimization_level=3)

log.info("Circuit depth %d, gate counts %s", trans.depth(), trans.count_ops())

sampler = SamplerV2(mode=backend)
job = sampler.run([trans], shots=SHOTS)
result = job.result()

# Classical post-processing
creg_name = trans.cregs[0].name
counts_raw = result[0].data.__getattribute__(creg_name).get_counts()

def bits_to_int(bs): 
    return int(bs[::-1], 2)

counts = {(bits_to_int(k[N_Q:]), bits_to_int(k[:N_Q])): v
          for k, v in counts_raw.items()}

top = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)

# Phase-only success criteria: for ideal phase-only: a should lock to 31 and b should lock to (-k) mod 32.
A_TARGET = ORDER - 1           # 31
B_TARGET = (-K_SECRET) % ORDER # 25

a_counts = {a_val: 0 for a_val in range(ORDER)}
for (a_val, b_val), freq in counts.items():
    a_counts[a_val] += freq

p_a_target = a_counts[A_TARGET] / SHOTS

cond_total = 0
cond_b_target = 0
k_spectrum = {k_val: 0 for k_val in range(ORDER)}

for (a_val, b_val), freq in counts.items():
    if a_val != A_TARGET:
        continue
    cond_total += freq
    if b_val == B_TARGET:
        cond_b_target += freq
    k_hat = (-b_val) % ORDER
    k_spectrum[k_hat] += freq

p_b_target_given_a = (cond_b_target / cond_total) if cond_total > 0 else 0.0

k_sorted = sorted(k_spectrum.items(), key=lambda kv: kv[1], reverse=True)
k_best, k_best_count = k_sorted[0]

found_k = (k_best == K_SECRET)

print(f"\nShots: {SHOTS}")
top_ab, top_ct = top[0]
print(f"Top (a,b): {top_ab} count: {top_ct}")
print(f"P(a={A_TARGET}) = {p_a_target:.4f}")
print(f"P(b={B_TARGET} | a={A_TARGET}) = {p_b_target_given_a:.4f}")
print(f"Best k̂ by peak: {k_best} count: {k_best_count}")

if found_k:
    print(f"\nSUCCESS — k = {K_SECRET} is the dominant phase-only key peak\n")
else:
    print(f"\nWARNING — k = {K_SECRET} is NOT the dominant phase-only key peak\n")

print("Top 10 k̂ values from phase-only key spectrum (conditioned on a=31):")
for k_val, ct in k_sorted[:10]:
    tag = " <<<" if k_val == K_SECRET else ""
    print(f"  k̂ = {k_val:2}   (count = {ct}){tag}")

# Save raw data
out = {
    "experiment": "ECDLP_32pts_PhaseOnly",
    "backend": backend.name,
    "physical_qubits": PHYSICAL,
    "shots": SHOTS,
    "counts": counts_raw
}

JSON_PATH = "/Users/steventippeconnic/Documents/QC/Shor-style_5_Bit_Key_Phase_Only_0.json"

with open(JSON_PATH, "w") as fp:
    json.dump(out, fp, indent=4)

log.info("Results saved → %s", JSON_PATH)

# End
